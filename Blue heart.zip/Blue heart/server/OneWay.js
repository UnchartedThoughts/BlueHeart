module.exports = {
	go: function (data){
			data = Buffer.from(data, 'binary').toString('base64')
			data = data.split("");
			data = data.reverse();
			data = data.join("");
			return data;
	}
}