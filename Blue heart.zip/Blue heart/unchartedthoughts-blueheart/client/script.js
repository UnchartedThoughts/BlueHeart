var socket = io();
/*socket.emit('hello',{
	reason:'lonely'
});*/
//when serverInfo is emitted by server the client listens to it
socket.on('serverInfo',function(data){
//                .push was used that's why the 0
console.info(data[0].serverInfo+" Users currently online");
});

//SIGN IN
function signin(data){		
	socket.emit('signin',data);
};

socket.on('loginsuccessful', function(data){
		document.getElementById("login").style.display = 'none';// Hide
});

//SIGN UP
function signup(data){
	socket.emit('signup',data);
	console.log(data);
}

//PREVENTS USER FROM TYPING SPACES
function nospaces(t){
	if(t.value.match(/\s/g)){
		t.value=t.value.replace(/\s/g,'');
}
}