//MONGODB
var url = "mongodb://unchartedthoughts:BH1357@ds053874.mlab.com:53874/blueheart";

//lets require/import the mongodb native drivers.
var mongodb = require('mongodb');
//OneWay
var oneway = require('./server/OneWay.js');//oneway.go(data);
//We need to work with "MongoClient" interface in order to connect to a mongodb server.
var MongoClient = mongodb.MongoClient;

//CONNECTS TO MY DB... THAT'S IT
MongoClient.connect(url, { useNewUrlParser: true }, function (err, db) {
	  if (err) {
		console.log('Unable to connect to the mongoDB server. Error:', err);
	  } else {
		console.log('Connection established to', url);
		db.close();
	  }
});	

//SAME AS ABOVE BUT ON CALLBACK LOOKS FOR SOMETHING THEN CALLBACKS IT IF FOUND
function queryCollection(type,match, callback) {
	MongoClient.connect(url, { useNewUrlParser: true }, function (err, db) {
	  if (err) {
		console.log('Unable to connect to the mongoDB server. Error:', err);
	  } else {
		  var dbName = db.db("blueheart");
		  dbName.collection(type).findOne(match, function(err,result){
				if (err) {
					console.log("error: " + err);
				}
				db.close();
				callback(err,result);
		  });
	  }
	});
}
//FUNCTION TO OPEN THE SERVER AND CHECK
/*queryCollection("account",{username:"kyle"}, function(result){
    console.log(result);
});*/
/*var mongojs = require('mongojs'); 
var db = mongojs('localhost:27017/blueheart', ['account', 'progress']);*/

//CHECKS COLLECTION AND THE MATCH ON THE DATA BASE ASYNC


//MONGODB

//EXPRESS FILE/PAGES REQUESTS
var express = require('express');
var app = express();
var serv = require('http').Server(app);

app.get('/',function (req, res){
	res.sendFile(__dirname + '/client/index.html');
});

app.use('/client',express.static(__dirname+'/client'));

serv.listen(process.env.PORT || 5000);
console.info("SERVER_BOOTED");
//EXPRESS

//SOCKET.IO INPUT/OUTPUT REQUESTS
var SOCKET_LIST = {};
var USER_LIST = {};
var NumberOfUsers = 0;

//Creates a User class to add attributes
var User = function(id){
	var self = {
		id:id,
		number:""+Math.floor(100000 * Math.random()),
		serverInfo:0
	}	
	return self;
}
//initializes socket on server
var io = require('socket.io')(serv,{});
io.sockets.on('connection', function(socket){
	 
	socket.id = Math.floor(100000 * Math.random());
	SOCKET_LIST[socket.id] = socket;
	console.info('User: '+socket.id+' has connected');
	
	var user = User(socket.id);
	USER_LIST[socket.id] = user;
	
	socket.on('disconnect', function(){
		console.info('User: '+socket.id+' has disconnected');
		delete SOCKET_LIST[socket.id];
		delete USER_LIST[socket.id];
	});
	
	//SIGN IN
	socket.on('signin', function(data){
		let success = true;
		queryCollection("account",{username:data.username, password: oneway.go(data.password)}, function(err,result){
			if (err) {
				success = false;
				return console.log("error: " + err);
			}
			if(result === null){
				success = false;
			}
			//IF LOGIN SUCCESSFUL
			if(success === true){	
				socket.emit('successful');
			}else{
				socket.emit('unsuccessful',);
			}	
		});
		console.log(success[0]);
	});
	//SIGN IN
	
	//SIGN UP
	socket.on('signup', function(data){
		let success = data.ohboy === ""?true:false;
		//CHECK USER ON DATABASES blah blah blah
		//data[0].userName . . .
		//IF LOGIN SUCCESSFUL
		if(success === true){
			socket.emit('successful');
		}else{
			socket.emit('unsuccessful');
		}
	});
	//SIGN UP
	
	/*socket.on('hello', function(data){
		console.log("message received reason: "+ data.reason);
	});*/
	
});
//SOCKET.IO

//REFRESH DATA FOR USERS
setInterval(function(){
	var pack = [];
	
	//Counts how many users
	for(var i in USER_LIST){
		NumberOfUsers++;
	}
	
	//Updates each user
	for(var i in USER_LIST){
		var user = USER_LIST[i];
		pack.push({
			number:user.number,
			serverInfo:NumberOfUsers
		});
	}
	//emits to each connected socket(user but not the class simple)
	for(var i in SOCKET_LIST){
		var socket = SOCKET_LIST[i];
		socket.emit('serverInfo', pack);
	}
	console.info(NumberOfUsers+ ' Users currently online');
	NumberOfUsers = 0;
},60000);
//REFRESH DATA FOR USERS