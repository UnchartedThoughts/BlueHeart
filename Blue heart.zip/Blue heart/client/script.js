var socket = io();

//when serverInfo is emitted by server the client listens to it
socket.on('serverInfo',function(data){
//                .push was used that's why the 0
console.info(data[0].serverInfo+" Users currently online");
});

//SIGN IN
function signin(data){
	socket.emit('signin',data);
};

//HIDES SIGNUP/LOGIN WHEN SUCCESFUL
socket.on('successful', function(data){
	console.info(data);
	document.getElementById("login").style.display = 'none';// Hide
	document.getElementById("signup").style.display = 'none';// Hide
	document.getElementById("menu").style.display = 'table';// Show
});

socket.on('unsuccessful', function(data){
	//Show and error message and clean fields
	console.log("UNSUCCESSFUL");
});

//SIGN UP
function signup(data){
	socket.emit('signup');
}

//PREVENTS USER FROM TYPING SPACES
function nospaces(t){
	if(t.value.match(/\s/g)){
		t.value=t.value.replace(/\s/g,'');
}
}